 
import './App.css';
import BookList from './containers/BookList/BookList'

function App() {
  return (
     <>
        <BookList/>
     </>
  );
}

export default App;
